function makeRed() {
    // document.getElementById('para').style.color = '#dc3545'
    document.getElementById('para').className = 'text-danger'
}