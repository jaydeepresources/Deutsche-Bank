var names = ['Brenda', 'John', 'Arjun', 'Dean', 'Dex']

function mapNamesToList() {
    var listString = ""

    for (let i = 0; i < names.length; i++) {
        listString += '<li class="list-group-item">' + names[i] + '</li>'
    }

    document.getElementById('namesUL').innerHTML = listString
}