// non-intrusive
// function hide() {
//     document.getElementById('para').hidden = true
// }

// function show() {
//     document.getElementById('para').hidden = false
// }

// intrusive
var text = "This is a sample text."

function hide() {
    document.getElementById('para').innerText = ''
}

function show() {
    document.getElementById('para').innerText = text
}