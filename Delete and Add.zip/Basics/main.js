var names = ['Brenda', 'John', 'Arjun', 'Dean', 'Dex']

function mapNamesToList() {
    var listString = ""

    for (let i = 0; i < names.length; i++) {
        listString +=
            `
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <span>${names[i]}</span>
                <button class="btn btn-danger" onclick="deleteName(${i})">x</button>
            </li>
            `
    }

    document.getElementById('namesUL').innerHTML = listString
}

function deleteName(i) {
    names.splice(i, 1)
    mapNamesToList()
}

function addName() {
    var newName = document.getElementById('textBox').value
    names.push(newName)
    mapNamesToList()
    document.getElementById('textBox').value = ''
}